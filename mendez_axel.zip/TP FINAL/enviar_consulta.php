<?php
$nombre = $_POST['nombre'];
$email = $_POST['email'];
$mensaje = $_POST['mensaje'];


$conexion = mysqli_connect('localhost', 'root', '', 'mendez_axel') or exit ("No se pudo conectar a la base de datos");

mysqli_query($conexion, "INSERT INTO consultas VALUES(DEFAULT, '$nombre', '$email', '$mensaje')");


mysqli_close($conexion);


header('Location:contacto.php?ok');