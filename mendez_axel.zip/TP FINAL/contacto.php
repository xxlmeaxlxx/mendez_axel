<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./styles.css">
</head>

<body>
    <header class="header">
        <h1 class="titulo">Bienvenidos a nuestra pagina</h1>
        <nav class="menu">
            <ul>
                <li><a href="index.php">Inicio</a></li>
                <li><a href="#">Tienda</a></li>
                <li><a href="personajes.php">Personajes</a></li>
                <li><a href="contacto.php">Contacto</a></li>
            </ul>
        </nav>
    </header>
    <section class="contacto">
        <h2> Contacto </h2>
        <div>
            <form action="enviar_consulta.php" method="post">
                <label for="nombre">Nombre</label>
                <input type="nombre" name="nombre">

                <label for="email">Correo electronico</label>
                <input type="email" name="email">

                <label for="mensaje">Mensaje</label>
                <textarea name="mensaje" id="mensaje"></textarea>

                <input type="submit" value="Enviar consulta">
            </form>
         
        </div>
    </section>
    <?php
            if (isset($_GET['ok'])) {
                echo "<h3> Mensaje enviado con éxito </h3>";
            }
            ?>
</body>

</html>